
Warning: require(../../sphinxapi.php): failed to open stream: No such file or directory in C:\Web\sphinx-2.3.2-beta-x64\share\doc\api\suggest.php on line 9

Fatal error: require(): Failed opening required '../../sphinxapi.php' (include_path='.;C:\php\pear') in C:\Web\sphinx-2.3.2-beta-x64\share\doc\api\suggest.php on line 9
